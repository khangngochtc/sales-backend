# Sales Backend
This is the backend service for the sales management system using Node.js, Express, and MySQL.